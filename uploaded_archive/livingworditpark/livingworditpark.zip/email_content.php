<?php
//include_once('header_page.php');
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<style>
	.email_content{
		
	}
	.email_content p{
		font-family: Tahoma, Calibri;
		font-size: 12px;
		color: #333333;
	}
	.email_content h3{
		
	}
</style>
<div style='background: #c1ddf1;
		padding: 5px;
		overflow: hidden;
		margin: 10px auto;'>
	<img src="header_img.png" />
	<br />
	<p style = 'font-family: Tahoma, Calibri;
		font-size: 12px;
		color: #333333;'>Hi user!</p>
	<h3 style='font-family: Tahoma, Calibri;
		font-size: 15px;
		color: #333333;'>Thank you for signing up!</h3>
	<p style = 'font-family: Georgia;
				font-size: 11px;
				color: #333333;
				text-decoration: italic;
				text-align: center;
				padding: 0px 20px;'>&ldquo;The gifts of the Master are these: freedom, life, hope, new direction, transformation, and intimacy with God. If the cross was the end of the story, we would have no hope. But the cross isn&lsquo;t the end. Jesus didn&lsquo;t escape from death; he conquered it and opened the way to heaven for all who will dare to believe. The truth of this moment, if we let it sweep over us, is stunning. It means Jesus really is who he claimed to be, we are really as lost as he said we are, and he really is the only way for us to intimately and spiritually connect with God again.&ldquo; 
<br />― Steven James, Story</p>
	<p style = 'font-family: Tahoma, Calibri;
		font-size: 12px;
		color: #333333;'>It is our prayer that you will grow in the Lord as you get involved with the different ministries of the church. We hope you will consider joining one today, if you don&lsquo;t have one yet.<br />
	<br /><br />
	Sincerely yours,<br /><br />
	Livingword IT Park<br /><br /></p>
	<p style = 'font-family: Tahoma, Calibri;
		font-size: 12px;
		color: #FFFFFF;
		background: #09385a;
		width: 500px;'>Skyrise 1 Bldg., AsiaTown IT Park, Lahug Cebu City, Philippines   | (032) 415 – 6148 </p>
</div>
</body>
</html>