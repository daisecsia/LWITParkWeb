<body>
	
<?php
	include_once('index_content.php');
?>
