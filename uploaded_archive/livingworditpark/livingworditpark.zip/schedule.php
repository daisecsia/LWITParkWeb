<?php
$menu_id = "schedule";
$page_title = "Schedule and Events";
include_once('header_page.php');
?>
<div class="page_wrapper">
	<div class="container">
		<div class="row">
			<div class="g6">
				<h2 class="h4">Upcoming Events</h2>
				<div id="eventCalendarCalendarSunday"></div>
			</div>
		</div>
	</div>
</div>
<?php
include_once('footer_page.php');
?>