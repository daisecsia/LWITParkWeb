<?php
$menu_id = "home";
$page_title = "Home";
include_once('header_page.php');
include_once('index_content.php');
include_once('footer_page.php');
?>